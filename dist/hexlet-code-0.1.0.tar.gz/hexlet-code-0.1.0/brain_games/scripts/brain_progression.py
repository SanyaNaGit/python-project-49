from brain_games.games import progression


def main():
    progression.run_game()


if __name__ == '__main__':
    main()
